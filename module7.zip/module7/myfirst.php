<!DOCTYPE html>
<html>
<body>

<?php
echo "Thanks for Subscribing!";
?> 

</body>
</html>